#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->frame->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_boton_leeme_clicked()
{
    ui->leeme->setText("Problema Productor-Consumidor:\n"
                       "Este problema consiste en tener\n"
                       "dos procesos donde el productor\n"
                       "da los elementos y el consumidor\n"
                       "los recibe\n"
                       "Ejecucion: Ingresar la cantidad\n"
                       "para consumidor y productor\n"
                       "Resultados: Mostrara el proceso\n"
                       "de ingresar y extraer elementos\n");
}

void MainWindow::on_boton_acerca_clicked()
{
    ui->acerca->setText("Universidad: La Salle\n"
                        "Curso: Sistemas Operativos\n"
                        "Profesor: Richart Escobedo\n"
                        "Alumno: Camila Huamaní\n"
                        "Semestre: V\n"
                        "Año academico: 2021-1\n"
                        "Fecha: 13/06/2021\n");
}

void MainWindow::on_boton_proceso_clicked()
{
    ui->frame->show();
    ui->numprod->setText("1");
    ui->numcom->setText("1");
}

void MainWindow::on_aceptar_clicked()
{
   ui->frame->hide();

}

void MainWindow::on_cancelar_clicked()
{
    ui->frame->hide();
}


#include "mainwindow.h"
#include <QApplication> //maneja archivos GUI

int main(int argc, char *argv[])
{
    QApplication a(argc, argv); //el objeto a es la aplicacion
    MainWindow w;//representa la ventana donde se ve todo
    w.show();

    return a.exec();
}

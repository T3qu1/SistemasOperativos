#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_boton_leeme_clicked();

    void on_boton_acerca_clicked();

    void on_boton_proceso_clicked();

    void on_aceptar_clicked();

    void on_cancelar_clicked();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
